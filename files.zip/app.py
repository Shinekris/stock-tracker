"""
app.py
Streamlit dashboard for the India wealth-creation tracker (priority edition).

Scores stocks on the top 3 tiers of direct-traceable wealth-creation
parameters, weighted by price-impact priority (Tier 1 x3, Tier 2 x2, Tier 3 x1).

Run with:
    python -m streamlit run app.py
"""

import sqlite3
import pandas as pd
import streamlit as st

import config
import scorer

st.set_page_config(page_title="India Stock Wealth Tracker",
                   page_icon="📈", layout="wide")


@st.cache_data(ttl=300)
def load_data():
    con = sqlite3.connect(config.DB_PATH)
    latest = pd.read_sql("SELECT MAX(date) AS d FROM daily_scores", con)["d"][0]
    if latest is None:
        con.close()
        return None, None, None
    scores = pd.read_sql(
        "SELECT * FROM daily_scores WHERE date = ? ORDER BY pct DESC",
        con, params=(latest,))
    raw = pd.read_sql("SELECT * FROM raw_data WHERE date = ?",
                      con, params=(latest,))
    history = pd.read_sql(
        "SELECT date, ticker, pct FROM daily_scores ORDER BY date", con)
    con.close()
    return latest, scores.merge(raw, on=["date", "ticker"], how="left"), history


def grade_dot(g):
    return {"A+": "🟢", "A": "🟢", "B": "🔵", "C": "🟡", "D": "🔴"}.get(g, "⚪")


latest_date, df, history = load_data()
st.title("📈 India Stock Wealth-Creation Tracker")

if df is None or df.empty:
    st.warning("No data yet. Run `python collector.py --test 5` first, "
               "then refresh.")
    st.stop()

live_params = [k for k, p in config.PRIORITY_PARAMS.items() if p.get("live")]
st.caption(f"Latest data: **{latest_date}**  •  {len(df)} stocks  •  "
           f"Tier-weighted score on {len(live_params)} live priority "
           f"parameters (of {len(config.PRIORITY_PARAMS)} total)")

tab1, tab2, tab3, tab4 = st.tabs(
    ["🏆 Leaderboard", "🔍 Screener", "💼 Portfolio", "🔬 Deep Dive"])

# --------------------------------------------------------------------------- #
# TAB 1 - Leaderboard
# --------------------------------------------------------------------------- #
with tab1:
    st.subheader("Ranked by tier-weighted priority score")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Stocks", len(df))
    c2.metric("Top score", f"{df['pct'].max():.1f}%")
    c3.metric("Average", f"{df['pct'].mean():.1f}%")
    c4.metric("Grade A / A+", int(df["grade"].isin(["A", "A+"]).sum()))

    board = df[["ticker", "pct", "grade", "total_score", "max_score"]].copy()
    board.insert(0, "Rank", range(1, len(board) + 1))
    board["Grade"] = board["grade"].apply(lambda g: f"{grade_dot(g)} {g}")
    board = board.rename(columns={"ticker": "Stock", "pct": "Score %",
                                  "total_score": "Wtd Pts", "max_score": "Max"})
    st.dataframe(
        board[["Rank", "Stock", "Score %", "Grade", "Wtd Pts", "Max"]],
        width='stretch', hide_index=True,
        column_config={"Score %": st.column_config.ProgressColumn(
            "Score %", min_value=0, max_value=100, format="%.1f%%")})
    st.bar_chart(df.set_index("ticker")["pct"], height=300)

# --------------------------------------------------------------------------- #
# TAB 2 - Screener
# --------------------------------------------------------------------------- #
with tab2:
    st.subheader("Filter and shortlist")
    a, b = st.columns(2)
    with a:
        min_score = st.slider("Minimum score %", 0, 100, 60)
        min_roe = st.slider("Minimum ROE %", 0, 60, 15)
    with b:
        max_de = st.slider("Maximum Debt/Equity", 0.0, 3.0, 1.0, 0.1)
        max_pledge = st.slider("Maximum Promoter Pledge %", 0, 50, 10)

    f = df.copy()
    f = f[f["pct"] >= min_score]
    f = f[f["roe"].fillna(0) >= min_roe]
    f = f[f["debt_to_equity"].fillna(99) <= max_de]
    f = f[f["promoter_pledge"].fillna(0) <= max_pledge]
    st.write(f"**{len(f)} stocks** match:")
    if not f.empty:
        show = f[["ticker", "pct", "grade", "roe", "roce",
                  "revenue_growth", "debt_to_equity", "promoter_pledge"]].rename(
            columns={"ticker": "Stock", "pct": "Score %", "grade": "Grade",
                     "roe": "ROE", "roce": "ROCE",
                     "revenue_growth": "Rev Gr%", "debt_to_equity": "D/E",
                     "promoter_pledge": "Pledge%"})
        st.dataframe(show, width='stretch', hide_index=True)
    else:
        st.info("No matches. Loosen the filters.")

# --------------------------------------------------------------------------- #
# TAB 3 - Portfolio
# --------------------------------------------------------------------------- #
with tab3:
    st.subheader("Monitor your holdings")
    owned = st.multiselect("Your holdings", sorted(df["ticker"].tolist()))
    if owned:
        p = df[df["ticker"].isin(owned)]
        st.metric("Portfolio average score", f"{p['pct'].mean():.1f}%")
        show = p[["ticker", "pct", "grade", "price"]].rename(
            columns={"ticker": "Stock", "pct": "Score %",
                     "grade": "Grade", "price": "Price ₹"})
        st.dataframe(show, width='stretch', hide_index=True)
        weak = p[p["pct"] < 60]
        if not weak.empty:
            st.warning("⚠️ Below-60% holdings: " + ", ".join(weak["ticker"]))
    else:
        st.info("Select one or more stocks above.")

# --------------------------------------------------------------------------- #
# TAB 4 - Deep Dive (tier-grouped)
# --------------------------------------------------------------------------- #
with tab4:
    st.subheader("Per-parameter breakdown by tier")
    stock = st.selectbox("Choose a stock", sorted(df["ticker"].tolist()))
    row = df[df["ticker"] == stock].iloc[0]
    st.metric(f"{stock} priority score", f"{row['pct']:.1f}%  ({row['grade']})")

    for tier in (1, 2, 3):
        keys = [k for k, p in config.PRIORITY_PARAMS.items() if p["tier"] == tier]
        st.markdown(f"**{config.TIER_NAME[tier]}**  "
                    f"_(weight ×{config.TIER_WEIGHT[tier]})_")
        recs = []
        for k in keys:
            p = config.PRIORITY_PARAMS[k]
            val = row.get(k)
            if not p.get("live"):
                recs.append({"Parameter": p["label"], "Value": "—",
                             "Score": "—", "Rating": "⏳ pending source"})
                continue
            s = scorer.score_value(k, val)
            if s is None:
                rating = "⚪ no data"
            else:
                rating = {3: "🟢 Strong", 2: "🟡 Average",
                          1: "🔴 Weak"}[s]
            recs.append({
                "Parameter": p["label"],
                "Value": "—" if val is None else str(round(val, 2)),
                "Score": "—" if s is None else str(s),
                "Rating": rating,
            })
        st.dataframe(pd.DataFrame(recs), width='stretch', hide_index=True)

    h = history[history["ticker"] == stock]
    if len(h) > 1:
        st.write("**Score trend**")
        st.line_chart(h.set_index("date")["pct"], height=250)
    else:
        st.caption("Trend chart appears once you have 2+ days of data.")

st.divider()
st.caption("⚠️ For research and educational use only. Not financial advice. "
           "Always consult a SEBI-registered adviser before investing.")
