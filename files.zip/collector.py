"""
collector.py
Batch data collector for the India wealth-creation tracker.

Fetches the LIVE priority parameters from free sources:
  - yfinance     -> price + 52-week momentum
  - Screener.in  -> ROE, ROCE, revenue growth, profit/EPS growth,
                    revenue growth acceleration, operating margin (OPM),
                    dividend yield, plus filter fields (D/E, pledge, etc.)

Usage:
    python collector.py            # all stocks in stocks.csv
    python collector.py --test 5   # first 5 stocks only (for testing)
"""

import sys
import csv
import time
import re

import requests
from bs4 import BeautifulSoup

try:
    import yfinance as yf
except ImportError:
    yf = None

import config
import database
import scorer


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def load_tickers():
    tickers = []
    with open(config.STOCK_LIST_FILE, newline="") as f:
        for row in csv.DictReader(f):
            t = (row.get("ticker") or "").strip().upper()
            if t:
                tickers.append(t)
    return tickers


def _retry(fn, *args, **kwargs):
    last_err = None
    for attempt in range(1, config.MAX_RETRIES + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            last_err = e
            wait = config.RETRY_BACKOFF * attempt
            print(f"    retry {attempt}/{config.MAX_RETRIES}: {e} (wait {wait}s)")
            time.sleep(wait)
    print(f"    giving up: {last_err}")
    return None


def _num(text):
    if not text:
        return None
    m = re.search(r"-?[\d,]+\.?\d*", text.replace(",", ""))
    return float(m.group()) if m else None


# ---------------------------------------------------------------------------
# yfinance: price + 52-week momentum
# ---------------------------------------------------------------------------
def fetch_price_data(tickers):
    out = {}
    if yf is None:
        print("yfinance not installed - skipping price data")
        return out
    yf_tickers = [f"{t}.NS" for t in tickers]
    print(f"Fetching 1y price history for {len(yf_tickers)} stocks...")
    data = _retry(yf.download, yf_tickers, period="1y",
                  group_by="ticker", progress=False, threads=True)
    if data is None:
        return out
    for t in tickers:
        try:
            df = data[f"{t}.NS"] if len(tickers) > 1 else data
            closes = df["Close"].dropna()
            if len(closes) < 2:
                continue
            first, last = closes.iloc[0], closes.iloc[-1]
            out[t] = {
                "price": round(float(last), 2),
                "price_momentum_52w": round(100 * (last - first) / first, 1),
            }
        except Exception:
            continue
    return out


# ---------------------------------------------------------------------------
# Screener.in parsing
# ---------------------------------------------------------------------------
def _parse_top_ratios(soup):
    out = {}
    for li in soup.select("ul#top-ratios li"):
        name_el = li.select_one(".name")
        val_el = li.select_one(".value")
        if not name_el or not val_el:
            continue
        name = name_el.get_text(strip=True).lower()
        val = _num(val_el.get_text(strip=True))
        out[name] = val
    return out


def _parse_ranges(soup):
    """Parse Screener's compounded-growth ranges tables."""
    out = {}
    for table in soup.select("table.ranges-table"):
        head = table.select_one("th")
        if not head:
            continue
        htext = head.get_text(strip=True).lower()
        rows = {}
        for tr in table.select("tr"):
            tds = tr.select("td")
            if len(tds) == 2:
                label = tds[0].get_text(strip=True).lower().rstrip(":")
                rows[label] = _num(tds[1].get_text(strip=True))
        if "sales growth" in htext:
            out["sales_ttm"] = rows.get("ttm")
            out["sales_3y"] = rows.get("3 years")
        elif "profit growth" in htext:
            out["profit_ttm"] = rows.get("ttm")
            out["profit_3y"] = rows.get("3 years")
    return out


def _parse_opm(soup):
    """Find the most recent OPM % from the P&L data tables."""
    for table in soup.select("table.data-table"):
        for tr in table.select("tr"):
            cells = tr.select("td")
            if not cells:
                continue
            label = cells[0].get_text(strip=True).lower()
            if label.startswith("opm"):
                vals = [_num(c.get_text(strip=True)) for c in cells[1:]]
                vals = [v for v in vals if v is not None]
                if vals:
                    return vals[-1]
    return None


def fetch_screener(ticker):
    url = f"https://www.screener.in/company/{ticker}/consolidated/"
    resp = requests.get(url, headers=config.REQUEST_HEADERS, timeout=20)
    if resp.status_code != 200:
        # Try standalone page if consolidated doesn't exist
        url = f"https://www.screener.in/company/{ticker}/"
        resp = requests.get(url, headers=config.REQUEST_HEADERS, timeout=20)
        if resp.status_code != 200:
            raise RuntimeError(f"HTTP {resp.status_code}")
    soup = BeautifulSoup(resp.text, "html.parser")

    top = _parse_top_ratios(soup)
    ranges = _parse_ranges(soup)

    # Revenue growth + acceleration
    rev_ttm = ranges.get("sales_ttm")
    rev_3y = ranges.get("sales_3y")
    accel = None
    if rev_ttm is not None and rev_3y is not None:
        accel = round(rev_ttm - rev_3y, 1)

    return {
        "roe":                  top.get("roe"),
        "roce":                 top.get("roce"),
        "dividend_payout":      top.get("dividend yield"),
        "opm":                  _parse_opm(soup),
        "revenue_growth":       rev_ttm if rev_ttm is not None else rev_3y,
        "revenue_growth_accel": accel,
        "eps_growth":           ranges.get("profit_ttm"),
        "profit_growth":        ranges.get("profit_ttm"),
        # filter fields
        "debt_to_equity":       top.get("debt to equity"),
        "current_ratio":        top.get("current ratio"),
        "promoter_holding":     top.get("promoter holding"),
        "promoter_pledge":      top.get("pledged percentage") or 0,
    }


# ---------------------------------------------------------------------------
# Main run
# ---------------------------------------------------------------------------
def run(limit=None):
    database.init_db()
    tickers = load_tickers()
    if limit:
        tickers = tickers[:limit]
    print(f"Collecting data for {len(tickers)} stocks\n")

    price_data = fetch_price_data(tickers)

    ok_count = 0
    for i, t in enumerate(tickers, 1):
        print(f"[{i}/{len(tickers)}] {t}")
        values = dict(price_data.get(t, {}))
        fundamentals = _retry(fetch_screener, t)
        if fundamentals:
            values.update(fundamentals)
            ok_count += 1
            fetch_ok = True
        else:
            fetch_ok = False
        database.save_raw(t, values, fetch_ok=fetch_ok)
        time.sleep(config.SCREENER_DELAY)

    print(f"\nFetched fundamentals for {ok_count}/{len(tickers)} stocks")

    print("Scoring all stocks (tier-weighted)...")
    scorer.score_all(tickers)

    latest, rows = database.latest_leaderboard()
    print(f"\n=== Priority Leaderboard ({latest}) ===")
    for rank, (tk, total, mx, pct, grade) in enumerate(rows, 1):
        print(f"{rank:3}. {tk:14} {pct:5.1f}%  ({grade})  [{total}/{mx} pts]")


if __name__ == "__main__":
    lim = None
    if len(sys.argv) > 2 and sys.argv[1] == "--test":
        lim = int(sys.argv[2])
    run(limit=lim)
