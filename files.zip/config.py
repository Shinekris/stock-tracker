"""
config.py
Central configuration for the India wealth-creation stock tracker.

This version focuses scoring on the TOP 3 TIERS of direct-traceable
wealth-creation parameters, weighted by price-impact priority:

    Tier 1  (Immediate movers)   -> weight x3
    Tier 2  (Sustained drivers)  -> weight x2
    Tier 3  (Re-rating factors)  -> weight x1

Each parameter is scored 3 (strong) / 2 (average) / 1 (weak), then multiplied
by its tier weight. "live" marks whether the collector can currently fetch it
from free sources (Screener.in + yfinance). Non-live ones show as "pending"
in the dashboard until the enrichment scrapers are added.
"""

# ---------------------------------------------------------------------------
# General settings
# ---------------------------------------------------------------------------
DB_PATH = "data/tracker.db"
STOCK_LIST_FILE = "stocks.csv"

SCREENER_DELAY = 2.5     # seconds between Screener.in requests (be polite)
MAX_RETRIES = 3
RETRY_BACKOFF = 5        # seconds, multiplied by attempt number

REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

# ---------------------------------------------------------------------------
# Tier weighting
# ---------------------------------------------------------------------------
TIER_WEIGHT = {1: 3, 2: 2, 3: 1}
TIER_NAME = {
    1: "Tier 1 - Immediate movers",
    2: "Tier 2 - Sustained drivers",
    3: "Tier 3 - Re-rating factors",
}

# ---------------------------------------------------------------------------
# Priority parameters (top 3 tiers, direct-traceable)
# key -> dict(label, tier, direction, cut3, cut2, live)
#   direction "higher": value >= cut3 -> 3 ; >= cut2 -> 2 ; else 1
#   direction "lower" : value <= cut3 -> 3 ; <= cut2 -> 2 ; else 1
# ---------------------------------------------------------------------------
PRIORITY_PARAMS = {
    # ---- Tier 1 ----
    "revenue_growth_accel": dict(
        label="Revenue Growth Acceleration (TTM vs 3yr, pp)",
        tier=1, direction="higher", cut3=5, cut2=0, live=True),

    # ---- Tier 2 ----
    "revenue_growth": dict(
        label="Revenue Growth YoY (%)",
        tier=2, direction="higher", cut3=20, cut2=10, live=True),
    "eps_growth": dict(
        label="EPS / Profit Growth (%)",
        tier=2, direction="higher", cut3=20, cut2=10, live=True),
    "price_momentum_52w": dict(
        label="52-Week Price Momentum (%)",
        tier=2, direction="higher", cut3=30, cut2=0, live=True),
    "fcf_growth": dict(
        label="Free Cash Flow Growth (%)",
        tier=2, direction="higher", cut3=20, cut2=5, live=False),
    "fii_buying": dict(
        label="FII / Institutional Buying (%)",
        tier=2, direction="higher", cut3=2, cut2=1, live=False),

    # ---- Tier 3 ----
    "roe": dict(
        label="ROE (%)",
        tier=3, direction="higher", cut3=25, cut2=15, live=True),
    "roce": dict(
        label="ROCE (%)",
        tier=3, direction="higher", cut3=20, cut2=12, live=True),
    "opm": dict(
        label="EBITDA / Operating Margin (%)",
        tier=3, direction="higher", cut3=20, cut2=12, live=True),
    "dividend_payout": dict(
        label="Dividend Yield / Capital Returns (%)",
        tier=3, direction="higher", cut3=1.5, cut2=0.5, live=True),
    "ocf_growth": dict(
        label="Operating Cash Flow Growth (%)",
        tier=3, direction="higher", cut3=20, cut2=5, live=False),
    "fcf_to_profit": dict(
        label="FCF to Net Profit Ratio",
        tier=3, direction="higher", cut3=0.8, cut2=0.4, live=False),
    "index_member": dict(
        label="Index Addition (Nifty membership)",
        tier=3, direction="higher", cut3=1, cut2=1, live=False),
}

# Extra fields still fetched for the Screener-filter tab (not part of the
# weighted priority score, but useful for filtering).
EXTRA_FILTER_FIELDS = [
    "debt_to_equity", "current_ratio", "promoter_holding", "promoter_pledge",
]
